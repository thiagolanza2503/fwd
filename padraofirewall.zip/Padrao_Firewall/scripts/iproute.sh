ip rule add from 192.168.2.254 table VIVO prio 300
ip route add 192.168.2.254 via 192.168.2.1 dev eth2 table VIVO
ip route add default via 192.168.2.1 table VIVO

ip rule add from 192.168.0.254 table NET prio 301
ip route add 192.168.0.254 via 192.168.0.1 dev eth1 table NET
ip route add default via 192.168.0.1 table NET


## POR MARCACAO DE PACOTE
ip rule add fwmark 443 lookup VIVO

###POR ARQUIVO DE IP
for NET in $(cat /root/scripts/ipsgerais);do
ip rule add from $NET lookup NET
done

ip route flush cached