#!/bin/bash

apt update -y

apt upgrade -y

apt install openvpn -y

apt install isc-dhcp-server -yy

apt install nload -y

apt install traceroute -y

apt install squid -y

apt install sarg -y

apt install ipset -y


cd /home/suprema/

wget https://github.com/thiagolanza2503/fwd/raw/main/padraofirewall.zip

unzip padraofirewall.zip


cp -r Padrao_Firewall/openvpn /etc/
cp -r Padrao_Firewall/scripts /root/
cp -r Padrao_Firewall/squid   /etc/
cp -r Padrao_Firewall/dhcpd.conf /etc/dhcp/
cp -r Padrao_Firewall/rc.local /etc/




cd /root/

chmod -R +x scripts

cd /etc/

chmod +x rc.local






