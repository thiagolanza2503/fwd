echo " EXECUCAO IPSET"

ipset -N brazil hash:net

mkdir ip-paises/

rm /root/scripts/ip-paises/br.zone

wget -P /root/scripts/ip-paises/. http://www.ipdeny.com/ipblocks/data/countries/br.zone

for i in $(cat /root/scripts/ip-paises/br.zone ); do ipset -A brazil $i; done
