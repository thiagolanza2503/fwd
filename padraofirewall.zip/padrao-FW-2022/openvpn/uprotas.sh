#!/bin/bash
route add -net 192.168.60.0/24 gw 10.0.0.2
