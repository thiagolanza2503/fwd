#!/bin/bash
 
GWUP=`ip route show | grep ^default | cut -d " " -f 3`
 
# Gateway Principal
GW1=186.249.232.125; export GW1 # Substitua pelo gateway do seu link principal
 
# Gateway Slave
GW2=192.168.0.1; export GW2 # Substitua pelo gateway do seu link backup
 
# Etapa 1 = Verifica se o gateway e o principal, ser for ele vai pra etapa 2 se nao for ele vai pra etapa 2.1
if [ $GWUP == $GW1 ]; then
 
   echo "`date` - Rota default e a Principal! Link Century 186.249.232.125" >> /var/log/redundancia.log
 
else
   route add -net 0.0.0.0 gw $GW1
   ping -I enp3s0 8.8.8.8 -c 5 -A > /dev/null
   if [ $? -eq 0 ]; then
 
#Epata 4 = Se o gateway principal voltou ele exclui a rota do gateway 2 para manter o gatewy 1 ativo
      echo "`date` - Link pricipal voltou!" >> /var/log/redundancia.log
      route del -net 0.0.0.0 gw $GW2
      route del default
      route add default gw $GW1
       echo nameserver 1.1.1.1 > /etc/resolv.conf
       echo nameserver 9.9.9.9 >> /etc/resolv.conf
      squid -k reconfigure
      /root/scripts/./iptables.rules
      /etc/init.d/openvpn restart
      exit 0
else

#Etapa 5 = Agora se o gateway principal nao voltou, ele deleta a rota do gateway 1 e mantem a rota do gateway 2
      echo "`date` - Link principal ainda nao voltou..." >> /var/log/redundancia.log
      echo "`date` - Link de backup sera mantido." >> /var/log/redundancia.log
      route del -net 0.0.0.0 gw $GW1	
      exit 0
   fi
 
fi
 
# Etapa 6 = Testando se o link principal com gateway 1 esta normal, se tiver ele vai pra etapa 7
echo "`date` - Testando Link Principal..." >> /var/log/redundancia.log
ping -I enp3s0 8.8.8.8 -c 5 -A > /dev/null
 
if [ $? -eq 0 ]; then
# Etapa 7 = Diz que o link principal com gateway 1 esta normal e finaliza
   echo "`date` - Link Principal UP!" >> /var/log/redundancia.log
else

# Etapa 8 = Diz que o link principal nao esta funcionado e deleta a rota do gateway um e adiciona rota ao gateway 2
   echo "`date` - Link Principal DOWN..." >> /var/log/redundancia.log
   echo "`date` - Subindo Link de backup..." >> /var/log/redundancia.log
   route del default
   route add default gw $GW2
   echo nameserver 9.9.9.9 >> /etc/resolv.conf
   echo nameserver 1.1.1.1 > /etc/resolv.conf
   squid -k reconfigure
   /root/scripts/./iptables.rules
   /etc/init.d/openvpn restart

fi
