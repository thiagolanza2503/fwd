#/bin/bash
####Monitor LINK ###
### Suprema Informatica ###
### Everton A.A 30/05/2017 ###
DATA=$(date)
## Testa Comunicação com Matriz
ping 10.0.0.1  -c 5 -A > /dev/null
if [ $? -eq 0 ]; then
echo VPN OK $DATA >> /var/log/monitorvpn.log
exit 0
else
openvpn --config /etc/openvpn/client.conf &
echo VPN CAIU $DATA >> /var/log/monitorvpn.log
exit 0
fi